export interface Product {
  id: string;
  name: string;
  badge: string;
  rating: number;
  reviews: number;
  price: number;
  originalPrice?: number;
  description: string;
  features: string[];
  whyPopular: string;
  imageUrl: string;
}

export const products: Product[] = [
  {
    id: "echo-dot-5th-gen",
    name: "Echo Dot (5th Generation)",
    badge: "Best Seller",
    rating: 4.7,
    reviews: 12482,
    price: 49.99,
    originalPrice: 59.99,
    description: "The most popular smart speaker with Alexa, featuring improved audio, temperature sensor, and new gesture controls. Perfect for any room, the Echo Dot delivers clear vocals and balanced bass for a full sound experience.",
    features: [
      "Improved audio quality",
      "Built-in temperature sensor",
      "New tap gesture controls",
      "100% recycled fabric materials",
      "Wi-Fi and Bluetooth connectivity",
      "Easy smart home integration"
    ],
    whyPopular: "The Echo Dot continues to dominate smart speaker sales due to its affordable price point, improved sound quality, and expanded Alexa capabilities. The addition of temperature sensors and enhanced smart home controls has made it the go-to choice for both new and existing smart home enthusiasts.",
    imageUrl: "https://images.unsplash.com/photo-1597872200969-2b65d56bd21b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "fire-tv-stick-4k-max",
    name: "Fire TV Stick 4K Max (2023)",
    badge: "Top Rated",
    rating: 4.8,
    reviews: 9345,
    price: 59.99,
    originalPrice: 74.99,
    description: "Amazon's most powerful streaming stick, featuring a new quad-core processor that's 40% more powerful than previous generations. Enjoy lightning-fast app starts and seamless 4K streaming with support for Dolby Vision, HDR10+, and Dolby Atmos audio.",
    features: [
      "40% more powerful processor",
      "Wi-Fi 6E support",
      "2GB RAM for faster performance",
      "Dolby Vision and HDR10+ support",
      "Dolby Atmos audio",
      "Ambient Experience mode"
    ],
    whyPopular: "The Fire TV Stick 4K Max has surged in popularity due to its unbeatable combination of performance and value. With the growing adoption of 4K TVs and increased streaming consumption, consumers are upgrading to devices that can handle higher-quality content. The new Wi-Fi 6E support ensures smoother streaming even in households with multiple connected devices.",
    imageUrl: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "kindle-paperwhite-signature",
    name: "Kindle Paperwhite Signature Edition",
    badge: "Editor's Choice",
    rating: 4.7,
    reviews: 7821,
    price: 189.99,
    originalPrice: 209.99,
    description: "The premium e-reader from Amazon features a 6.8\" display with adjustable warm light, wireless charging, and auto-adjusting front light. With 32GB of storage, you can store thousands of books in a device that's thinner and lighter than many paperbacks.",
    features: [
      "6.8\" glare-free display",
      "32GB storage capacity",
      "Wireless Qi charging",
      "Auto-adjusting front light",
      "Waterproof (IPX8 rated)",
      "Up to 10 weeks battery life"
    ],
    whyPopular: "As digital reading continues to grow, the Kindle Paperwhite Signature Edition has become a favorite for serious readers. The combination of premium features like wireless charging and auto-adjusting light with an expanded storage capacity makes this the perfect companion for avid readers, travelers, and those looking to reduce physical book clutter.",
    imageUrl: "https://images.unsplash.com/photo-1585298723682-7115561c51b7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "blink-outdoor-4",
    name: "Blink Outdoor 4 (4-Camera System)",
    badge: "Most Popular",
    rating: 4.6,
    reviews: 5234,
    price: 249.99,
    originalPrice: 379.99,
    description: "A complete home security solution with four wireless, weather-resistant HD cameras. Monitor your home day or night with infrared night vision and get real-time alerts when motion is detected. The extended battery life means you can go up to two years before replacing batteries.",
    features: [
      "1080p HD video quality",
      "Weather-resistant design",
      "Two-year battery life",
      "Infrared night vision",
      "Two-way audio",
      "Works with Alexa"
    ],
    whyPopular: "Home security has become a top priority for many homeowners, and the Blink Outdoor system offers an accessible solution without the need for professional installation or monthly fees. The long battery life and weather-resistant design make it perfect for continuous monitoring, while integration with Alexa allows for a seamless smart home experience.",
    imageUrl: "https://images.unsplash.com/photo-1544097784-3c9e1abb282e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "smart-garden-9-pro",
    name: "Smart Garden 9 Pro",
    badge: "Fastest Growing",
    rating: 4.9,
    reviews: 3872,
    price: 199.95,
    originalPrice: 229.95,
    description: "Grow fresh herbs and vegetables indoors all year round with this self-watering smart garden. The built-in grow lights automatically provide optimal lighting, while the smart soil ensures plants get the right amount of water, oxygen, and nutrients.",
    features: [
      "Grows 9 plants simultaneously",
      "Built-in LED grow lights",
      "Self-watering system",
      "Smart soil with nutrients",
      "Mobile app connectivity",
      "Energy-efficient design"
    ],
    whyPopular: "The Smart Garden 9 Pro has exploded in popularity as more people embrace sustainable living and food security. The pandemic-driven interest in home gardening has continued to grow, and this smart garden offers a foolproof solution for growing fresh herbs and vegetables regardless of space limitations, gardening experience, or climate. Its sleek design makes it a stylish addition to modern kitchens.",
    imageUrl: "https://images.unsplash.com/photo-1617396900799-f4ec2b43c7ae?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
  }
];
