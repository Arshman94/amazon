import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Introduction from "@/components/Introduction";
import ProductSection from "@/components/ProductSection";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";
import { products } from "@/data/products";
import { useEffect } from "react";

export default function Home() {
  // Smooth scroll handler for navigation links
  useEffect(() => {
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'A' && target.getAttribute('href')?.startsWith('#')) {
        e.preventDefault();
        const targetId = target.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId || '');
        if (!targetElement) return;
        
        const headerHeight = document.querySelector('header')?.offsetHeight || 0;
        const targetPosition = targetElement.getBoundingClientRect().top + window.scrollY;
        
        window.scrollTo({
          top: targetPosition - headerHeight,
          behavior: 'smooth'
        });
      }
    };

    document.addEventListener('click', handleAnchorClick);
    
    return () => {
      document.removeEventListener('click', handleAnchorClick);
    };
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <Hero />
      <Introduction />
      
      {products.map((product, index) => (
        <ProductSection 
          key={product.id} 
          product={product} 
          index={index} 
          id={`product${index + 1}`}
        />
      ))}
      
      <CTASection />
      <Footer />
    </div>
  );
}
