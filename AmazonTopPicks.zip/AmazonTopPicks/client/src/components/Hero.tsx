import { Link } from "wouter";

export default function Hero() {
  return (
    <section className="py-16 md:py-24 relative">
      <div className="container mx-auto px-4 text-center relative z-10">
        <div className="bg-black bg-opacity-70 p-8 rounded-lg backdrop-blur-sm max-w-3xl mx-auto">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold font-playfair mb-4 text-vintage-beige text-shadow">
            <span className="bg-gradient-gold bg-clip-text text-transparent">Top 5 Amazon Products</span>
            <span className="block mt-2">of 2024</span>
          </h1>
          <p className="text-lg md:text-xl max-w-2xl mx-auto mb-8 text-vintage-beige font-cormorant">
            Discover the most sophisticated and trending products on Amazon this year, with detailed information to help you make informed purchasing decisions.
          </p>
          <div className="flex justify-center">
            <Link href="#product1" className="bg-vintage-gold hover:bg-vintage-light-gold text-vintage-dark-green px-8 py-3 rounded-lg font-semibold transition-all transform hover:scale-105 shadow-lg border-2 border-vintage-dark-beige">
              Explore Premium Products
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
