import { Link } from "wouter";

export default function CTASection() {
  return (
    <section className="py-20 bg-vintage-dark-green relative">
      <div className="absolute inset-0 bg-black bg-opacity-30"></div>
      <div className="container mx-auto px-4 text-center relative z-10">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold font-playfair text-vintage-beige mb-6 text-shadow">
            Ready to explore these <span className="text-vintage-gold">premium products</span>?
          </h2>
          <p className="text-vintage-beige opacity-90 text-lg max-w-2xl mx-auto mb-8 font-cormorant text-xl">
            Get ahead of the curve and discover Amazon's most sophisticated products of 2024. 
            These items are sought after for their exceptional quality, elegant design, and outstanding value.
          </p>
          <Link 
            href="#" 
            className="inline-block bg-vintage-gold hover:bg-vintage-light-gold text-vintage-dark-green px-8 py-4 rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-lg border border-vintage-dark-beige"
          >
            Explore on Amazon
          </Link>
        </div>
      </div>
    </section>
  );
}
