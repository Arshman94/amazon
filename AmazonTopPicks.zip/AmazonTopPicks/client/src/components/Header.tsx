import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useMobile } from "@/hooks/use-mobile";
import { Menu } from "lucide-react";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const isMobile = useMobile();

  // Handle scroll for transparency effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  return (
    <header className={`fixed top-0 w-full z-50 ${isScrolled ? 'bg-vintage-dark-green bg-opacity-95' : 'bg-transparent'} transition-all duration-300 shadow-md`}>
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <h1 className="text-2xl font-bold font-playfair">
            <span className="text-vintage-beige">Amazon </span>
            <span className="text-vintage-gold">Top 5</span>
          </h1>
        </div>
        
        {/* Desktop Navigation */}
        {!isMobile && (
          <nav>
            <ul className="flex space-x-6">
              <li>
                <Link href="#product1" className="text-vintage-beige hover:text-vintage-gold transition-colors font-cormorant text-lg">Product 1</Link>
              </li>
              <li>
                <Link href="#product2" className="text-vintage-beige hover:text-vintage-gold transition-colors font-cormorant text-lg">Product 2</Link>
              </li>
              <li>
                <Link href="#product3" className="text-vintage-beige hover:text-vintage-gold transition-colors font-cormorant text-lg">Product 3</Link>
              </li>
              <li>
                <Link href="#product4" className="text-vintage-beige hover:text-vintage-gold transition-colors font-cormorant text-lg">Product 4</Link>
              </li>
              <li>
                <Link href="#product5" className="text-vintage-beige hover:text-vintage-gold transition-colors font-cormorant text-lg">Product 5</Link>
              </li>
            </ul>
          </nav>
        )}
        
        {/* Mobile Navigation Toggle */}
        {isMobile && (
          <button 
            onClick={toggleMenu} 
            className="text-vintage-beige text-xl"
            aria-label="Toggle navigation menu"
          >
            <Menu size={24} />
          </button>
        )}
      </div>
      
      {/* Mobile Navigation Menu */}
      {isMobile && (
        <div className={`bg-vintage-dark-green bg-opacity-95 backdrop-blur-sm border-t border-vintage-gold ${isMenuOpen ? 'block' : 'hidden'}`}>
          <ul className="py-2 px-4">
            <li className="py-2">
              <Link href="#product1" className="text-vintage-beige hover:text-vintage-gold block font-cormorant text-lg" onClick={closeMenu}>Product 1</Link>
            </li>
            <li className="py-2">
              <Link href="#product2" className="text-vintage-beige hover:text-vintage-gold block font-cormorant text-lg" onClick={closeMenu}>Product 2</Link>
            </li>
            <li className="py-2">
              <Link href="#product3" className="text-vintage-beige hover:text-vintage-gold block font-cormorant text-lg" onClick={closeMenu}>Product 3</Link>
            </li>
            <li className="py-2">
              <Link href="#product4" className="text-vintage-beige hover:text-vintage-gold block font-cormorant text-lg" onClick={closeMenu}>Product 4</Link>
            </li>
            <li className="py-2">
              <Link href="#product5" className="text-vintage-beige hover:text-vintage-gold block font-cormorant text-lg" onClick={closeMenu}>Product 5</Link>
            </li>
          </ul>
        </div>
      )}
    </header>
  );
}
