import { Check } from "lucide-react";
import { Product } from "@/data/products";

interface ProductSectionProps {
  product: Product;
  index: number;
  id: string;
}

const ProductSection = ({ product, index, id }: ProductSectionProps) => {
  // Alternate between beige and transparent background
  const bgClass = index % 2 === 0 
    ? "bg-white bg-opacity-80" 
    : "bg-vintage-dark-beige bg-opacity-20";

  return (
    <section id={id} className={`py-16 relative`}>
      <div className="container mx-auto px-4">
        <div className={`${bgClass} backdrop-blur-sm rounded-xl shadow-xl overflow-hidden mb-12 border border-vintage-dark-beige`}>
          <div className="flex flex-col lg:flex-row">
            <div className="lg:w-2/5 p-6 flex items-center justify-center bg-white bg-opacity-90">
              <img 
                src={product.imageUrl} 
                alt={product.name} 
                className="max-h-96 object-contain rounded-lg shadow-md" 
              />
            </div>
            <div className="lg:w-3/5 p-6 md:p-8">
              <div className="flex items-center mb-4">
                <span className="bg-vintage-gold text-vintage-dark-green text-sm font-bold px-3 py-1 rounded-full mr-3 shadow-sm">
                  #{index + 1}
                </span>
                <span className="bg-vintage-green bg-opacity-20 text-vintage-dark-green px-3 py-1 rounded-full text-sm border border-vintage-green">
                  {product.badge}
                </span>
              </div>
              <h2 className="text-2xl md:text-3xl font-bold font-playfair text-vintage-dark-green mb-3">
                {product.name}
              </h2>
              <div className="flex items-center mb-4">
                <div className="flex text-vintage-gold">
                  {Array(Math.floor(product.rating)).fill(0).map((_, i) => (
                    <svg key={i} xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118l-2.8-2.034c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                  {product.rating % 1 !== 0 && (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118l-2.8-2.034c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  )}
                </div>
                <span className="ml-2 text-vintage-brown font-cormorant text-lg">
                  {product.rating.toFixed(1)} ({product.reviews.toLocaleString()} reviews)
                </span>
              </div>
              <div className="mb-6">
                <span className="text-2xl font-bold font-playfair text-vintage-dark-green">${product.price.toFixed(2)}</span>
                {product.originalPrice && (
                  <>
                    <span className="ml-2 text-vintage-brown line-through">${product.originalPrice.toFixed(2)}</span>
                    <span className="ml-2 text-vintage-green font-medium">
                      Save {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}%
                    </span>
                  </>
                )}
              </div>
              <p className="text-vintage-brown mb-6 font-cormorant text-lg">{product.description}</p>
              
              <h3 className="font-bold font-playfair text-lg mb-3 text-vintage-dark-green border-b border-vintage-gold pb-2 inline-block">Key Features:</h3>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6 mt-3">
                {product.features.map((feature, i) => (
                  <li key={i} className="flex items-start">
                    <Check className="text-vintage-gold mt-1 mr-2 h-4 w-4" />
                    <span className="font-cormorant text-lg">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <h3 className="font-bold font-playfair text-lg mb-3 text-vintage-dark-green border-b border-vintage-gold pb-2 inline-block">Why It's Popular:</h3>
              <p className="text-vintage-brown mb-6 font-cormorant text-lg mt-3">{product.whyPopular}</p>
              
              <a 
                href="#" 
                className="inline-block bg-vintage-dark-green hover:bg-vintage-green text-vintage-beige px-6 py-3 rounded-lg font-semibold transition-all border border-vintage-gold shadow-md"
              >
                View on Amazon
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductSection;
