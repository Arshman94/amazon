import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-vintage-dark-green py-10 text-vintage-beige relative">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-xl font-bold font-playfair mb-4 border-b border-vintage-gold pb-2 inline-block">About This Site</h3>
            <p className="text-vintage-beige opacity-90 font-cormorant text-lg">
              This website showcases the top trending Amazon products of 2024. 
              We carefully research and select products based on sales data, 
              customer reviews, and overall popularity.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-bold font-playfair mb-4 border-b border-vintage-gold pb-2 inline-block">Quick Links</h3>
            <ul className="space-y-2 font-cormorant text-lg">
              <li>
                <Link href="#" className="text-vintage-beige opacity-90 hover:text-vintage-gold transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="#product1" className="text-vintage-beige opacity-90 hover:text-vintage-gold transition-colors">
                  Top Products
                </Link>
              </li>
              <li>
                <Link href="#" className="text-vintage-beige opacity-90 hover:text-vintage-gold transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="#" className="text-vintage-beige opacity-90 hover:text-vintage-gold transition-colors">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-xl font-bold font-playfair mb-4 border-b border-vintage-gold pb-2 inline-block">Contact Us</h3>
            <p className="text-vintage-beige opacity-90 mb-4 font-cormorant text-lg">
              Have questions about our product recommendations? We'd love to hear from you!
            </p>
            <a href="mailto:info@amazontop5.com" className="text-vintage-gold hover:underline font-cormorant text-lg">
              info@amazontop5.com
            </a>
          </div>
        </div>
        <div className="border-t border-vintage-gold border-opacity-30 pt-6 text-center">
          <p className="text-vintage-beige opacity-80 font-cormorant">
            &copy; 2024 Amazon Top 5. All rights reserved. This site is not affiliated with Amazon.com, Inc.
          </p>
          <p className="text-vintage-beige opacity-60 text-sm mt-2 font-cormorant">
            Product prices and availability are accurate as of the date/time indicated and are subject to change.
          </p>
        </div>
      </div>
    </footer>
  );
}
