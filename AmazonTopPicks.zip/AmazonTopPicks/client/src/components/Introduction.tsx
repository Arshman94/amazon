import { Star, DollarSign, ThumbsUp, Zap } from "lucide-react";

export default function Introduction() {
  const features = [
    { icon: <Star className="text-vintage-dark-green text-xl" />, title: "Top-Rated" },
    { icon: <DollarSign className="text-vintage-dark-green text-xl" />, title: "Best Value" },
    { icon: <ThumbsUp className="text-vintage-dark-green text-xl" />, title: "Customer Favorites" },
    { icon: <Zap className="text-vintage-dark-green text-xl" />, title: "Trending Now" },
  ];

  return (
    <section className="py-16 relative">
      <div className="container mx-auto px-4">
        <div className="bg-white bg-opacity-90 backdrop-blur-sm rounded-lg p-8 shadow-xl max-w-3xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-bold font-playfair mb-6 text-vintage-dark-green text-center">
            <span className="border-b-2 border-vintage-gold pb-2">Why These Products Are Trending</span>
          </h2>
          <p className="text-vintage-brown mb-8 font-cormorant text-xl">
            Our team has analyzed thousands of customer reviews, sales data, and product features to bring you the definitive list of Amazon's best-selling products for 2024. Each product has been carefully selected based on popularity, innovation, value for money, and customer satisfaction.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-10">
            {features.map((feature, index) => (
              <div key={index} className="flex flex-col items-center">
                <div className="w-14 h-14 bg-vintage-gold bg-opacity-80 rounded-full flex items-center justify-center mb-3 border border-vintage-dark-beige shadow-md">
                  {feature.icon}
                </div>
                <p className="font-cormorant font-semibold text-lg text-vintage-dark-green">{feature.title}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
